<?php
/**
 * @package AD Schedule
 * @version 0.1
 */
/*
Plugin Name: Ad Schedule
Description: Ad campaigns controller & scheduler for Radio Station Websites.
Author: PromoSuite
Version: 0.1
Author URI: Promosuite.com
*/

function ads_add_expiration_field()
{
	global $post_type;

	if ($post_type == 'ads')
	{
		wp_enqueue_style( 'jquery-ui-css', plugin_dir_url( __FILE__ ).'css/jquery-ui-fresh.min.css' );
		wp_enqueue_style( 'jquery-ui-css', plugin_dir_url( __FILE__ ).'css/jquery-ui-timepicker-addon.css' );
		wp_enqueue_style( 'jquery-ui-css', plugin_dir_url( __FILE__ ).'css/hide.css' );
		//wp_enqueue_script('jquery-script', 'http://code.jquery.com/ui/1.10.4/jquery-ui.js');
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-time-picker' ,  plugin_dir_url( __FILE__ ). 'js/jquery-ui-timepicker-addon.js',  array('jquery' ));
		wp_enqueue_script( 'ad-expiration', plugin_dir_url( __FILE__ ).'js/edit.js' );

		global $post;

		if( ! empty( $post->ID ) ) {
			$range = get_post_meta( $post->ID, 'ad-range', true );
			$parts = explode(' - ', $range);

			$ad_from = isset( $parts[0] ) ? $parts[0] : '';
			$ad_to = isset( $parts[1] ) ? $parts[1] : '';
		}

		//$format = get_option( 'date_format' );
		$format = 'm/d/Y h:i a';
		//echo $ad_from;
		$ad_from  = ! empty( $ad_from ) ? date_i18n( $format, strtotime( $ad_from ) ) : '';
		$ad_to  = ! empty( $ad_to ) ? date_i18n( $format, strtotime( $ad_to ) ) : '';
		//the_time( get_option( 'date_format' ) );
?>
	<style>.ui-datepicker{margin-top: 50px;}</style>
	<div id=="ad-expiration-wrap" class="misc-pub-section">
	<input type="hidden" name="ADmeta_noncename" id="ADmeta_noncename" value="<?php echo wp_create_nonce( plugin_basename(__FILE__) ); ?>" />
		<span>
			<span class="wp-media-buttons-icon dashicons dashicons-calendar"></span>&nbsp;
			<?php _e( 'Schedule for:', 'ad' ); ?>
		</span>
		<a href="#" id="ad-edit-expiration" class="ad-edit-expiration hide-if-no-js">
			<span class="screen-reader-text"><?php _e( 'Edit date and time', 'ad' ); ?></span>
		</a>
		<div id="ad-expiration-field" class="hide-if-no-js">
			<p>
				<label for="ad-from-date" style="width:50px;display:inline-block;">From:</label><input type="text" name="ad-from-date" id="ad-from-date" value="<?php echo esc_attr( $ad_from ); ?>" placeholder="now"/><br>
				<label for="ad-to-date" style="width:50px;display:inline-block;">To:</label><input type="text" name="ad-to-date" id="ad-to-date" value="<?php echo esc_attr( $ad_to ); ?>" placeholder="forever"/>
			</p>
		</div>
	</div>
<?php
	}
}
add_action( 'post_submitbox_misc_actions', 'ads_add_expiration_field' );


function register_ads_posttype()
{
	register_post_type( 'ads',
		array(
		'labels' => array(
			'name' => __( 'Ads' ),
			'singular_name' => __( 'Ad' ),
			'add_new' => __( 'Add New Ad' ),
			'add_new_item' => __( 'Add New Ad' ),
			'edit_item' => __( 'Edit Ad' ),
			'new_item' => __( 'Add New Ad' ),
			'view_item' => __( 'View Ad' ),
			'search_items' => __( 'Search Ad' ),
			'not_found' => __( 'No Ads found' ),
			'not_found_in_trash' => __( 'No Ads found in trash' )
		),
		'public' => true,
		'supports' => array( 'title', 'editor' ),
		'capabilities'         => array(),
		//'capability_type' => 'post',
		'rewrite' => array("slug" => "ads"), // Permalinks format
		'menu_position' => 5,
		'exclude_from_search' => true,
		)
	);
}
add_action( 'init', 'register_ads_posttype' );

// Save the Data
function wpt_save_ads_meta($post_id, $post) {
	// verify this came from the our screen and with proper authorization,
	// because save_post can be triggered at other times
	if ( !isset($_POST['ADmeta_noncename']) || !wp_verify_nonce( $_POST['ADmeta_noncename'], plugin_basename(__FILE__) )) {
		return $post->ID;
	}

	// Is the user allowed to edit the post or page?
	if ( !current_user_can( 'edit_post', $post->ID ))
	return $post->ID;

	$custom_meta['ad-range'] ="{$_POST['ad-from-date']} - {$_POST['ad-to-date']}";

	// Add values of $djs_meta as custom fields
	foreach ($custom_meta as $key => $value) {
		if( $post->post_type == 'revision' ) return; // Don't store custom data twice
		if(get_post_meta($post->ID, $key, FALSE)) { // If the custom field already has a value
			update_post_meta($post->ID, $key, $value);
		} else { // If the custom field doesn't have a value
			add_post_meta($post->ID, $key, $value);
		}
		if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
	}

}
add_action('save_post', 'wpt_save_ads_meta', 1, 2); // save the custom fields

// Remove quick edit
function remove_quick_edit_ad( $actions )
{
	global $post_type;

	if ($post_type == 'ads')
	{
		unset($actions['inline hide-if-no-js']);
	}
	return $actions;
}
add_filter('post_row_actions','remove_quick_edit_ad', 10, 1);

require_once('widget.php');

//install
register_activation_hook(__FILE__,'promosuite_ad_widget_install');
//add_action('widgets_init',create_function('','return register_widget("ad_widget");'));
function promosuite_ad_widget_install()
{
	global $wpdb;
	if($wpdb->get_var('show tables like \''.ad_widget::$dbtable.'\'')!=ad_widget::$dbtable){
		$sql='CREATE TABLE IF NOT EXISTS `'.ad_widget::$dbtable.'` (
  		`widget_id` varchar(15) NOT NULL,
  		`ad_id` int(10) unsigned NOT NULL,
  		`often` tinyint(3) unsigned NOT NULL,
  		KEY `widget_id` (`widget_id`)
		) DEFAULT CHARSET=latin1;';
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
}
?>