jQuery(document).ready(function($) {

	//document.getElementById("visibility").innerHTML='Visibility: <span id="post-visibility-display">According to schedule</span>';
	$('#visibility').hide();
	$('#post-preview').hide();
	$('#edit-slug-box').hide();
	$('.curtime').hide();
	jQuery('#ad-from-date').datetimepicker({timeFormat: 'hh:mm tt', dateFormat: "mm/dd/yy", showOptions: { direction: "down" }});
	jQuery('#ad-to-date').datetimepicker({timeFormat: 'hh:mm tt', dateFormat: "mm/dd/yy", showOptions: { direction: "down" }});
});