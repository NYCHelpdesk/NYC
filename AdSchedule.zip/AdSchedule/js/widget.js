jQuery(document).ready(function($)
{
	$(document).on('click','.button_ad_',function(e)
	{
		e.preventDefault();
		var id=$(this).data('id');
		var v = $('#value_ad_'+id).val();
		var w = $('#often_ad_'+id).val();

		//alert(id+v+w);

		$.ajax({
			url:ajaxurl,
			type:'post',
			data:{action:'placement_add', ad:v,id:id,often:w},
			success:function(resp)
			{
				if (resp=='done')
				{
					//alert(resp);
					//alert();
					place_ad (id, v, w);
				}
				else alert('ERROR! You can`t add same ad to instance twice, use weight to set how often it will appear!');
				return 1;
			}
		});

	});

	$(document).on('click','.promosuite-ads-delete',function(e)
	{
		e.preventDefault();
		var widget_id=$(this).data('widget');
		var ad_id=$(this).data('ad');
		var title=$(this).data('title');

		$.ajax({
			url:ajaxurl,
			type:'post',
			data:{action:'placement_delete', widget_id:widget_id,ad_id:ad_id},
			success:function(resp)
			{
				if (resp=='done')
				{
					remove_ad(widget_id, ad_id)
					//alert(ad_array[ad_id]);
				}
				else alert('ERROR! Can`t delete, please reload the page.');
				return 1;
			}
		});

	});

	function place_ad(widget, ad, often)
	{
		var title = ad_array[ad];
		var div = $('#ad_list_'+widget);
		var line = "<span id = 'w_"+widget+"_ad_"+ad+"'><i>"+title+"</i> ["+often+"] <a href='#' class='promosuite-ads-delete' data-widget='"+widget+"' data-ad='"+ad+"'>delete</a><br></span>";
		div.html(div.html()+line);
		//<span id = 'w_{$instance['id']}_ad_{$placed_ad->ad_id}'>
	}
	function remove_ad(widget, ad)
	{
		//$('#ad_list_'+widget).remove('#w_'+widget+'_ad_'+ad);
		$('#w_'+widget+'_ad_'+ad).remove();
	}

});
