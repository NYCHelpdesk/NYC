<?
class ad_widget extends WP_Widget
{
	public static $dbtable='promosuite_ads_rel';

	function __construct()
	{
		parent::__construct('ad_widget', __('Ad campaign'),
		array( 'description' =>__('Display selected ads.'))
		);

		add_action('wp_ajax_placement_add',array($this,'placement_add'));
		add_action('wp_ajax_placement_delete',array($this,'placement_delete'));
	}

	function placement_add()
	{
		global $wpdb;
		$sql='INSERT INTO `'.self::$dbtable.'`(`widget_id`,`ad_id`,`often`) ';
		$sql.='VALUES("'.$_POST['id'].'",'.$_POST['ad'].','.$_POST['often'].')';
		$r = $wpdb->query($sql);
		echo 'done';
		wp_die();
	}
	function placement_delete()
	{
		if(!empty($_SERVER['HTTP_X_REQUESTED_WITH'])&&strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])=='xmlhttprequest'){
			global $wpdb;
			$sql='DELETE FROM `'.self::$dbtable.'` WHERE `ad_id`='.intval($_POST['ad_id']).' AND `widget_id` = "'.$_POST['widget_id'].'" LIMIT 1;';
			try{
				$wpdb->query($sql);
			}catch(Exception $e){
				echo 'ERROR:';
				var_dump($e);
			}
			echo 'done';
		}

		wp_die();
	}
	public function widget( $args, $instance )
	{
		$list = $this->get_active($instance['id']);

		if (!count($list)) return false;
		$total = 0;
		foreach ($list as $ad)
		{
			$total+=$ad->often;
		}
		$pos = rand(1, $total);
		$show_ad=0;
		foreach ($list as $ad)
		{
			$pos -= $ad->often;
			if ($pos<1)
			{
				$show_ad = $ad->ad_id;
				break;
			}
		}
		echo $args['before_widget'];

		$content_post = get_post($show_ad);
		echo wpautop($content_post->post_content);

		echo $args['after_widget'];
	}
	private function get_all($widget)
	{
		global $wpdb;
		$t = self::$dbtable;
		$querystr = "SELECT * FROM `{$t}` WHERE `widget_id` = '{$widget}'";
		return $wpdb->get_results($querystr, OBJECT);
	}
	private function get_active($widget)
	{
		$list = $this->get_all($widget);
		date_default_timezone_set(get_option('timezone_string'));
		$now = time();
		foreach ($list as $k=>$rel)
		{
			$range = $this->get_range($rel->ad_id);
			$parts = explode('-', $range);

			if (isset($parts[0]) && strlen($parts[0])>10)
			{
				$from = strtotime($parts[0]);
				if ($from>$now)
				{
					unset($list[$k]);
					continue;
				}
			}
			else continue;

			if (isset($parts[1]) && strlen($parts[1])>10)
			{

				$from = strtotime($parts[1]);
				if ($from<$now)
				{
					unset($list[$k]);
					continue;
				}
			}
			else continue;

		}
		return $list;
	}
	private function get_range($post)
	{
		global $wpdb;
		$querystr = "SELECT `meta_value` FROM `{$wpdb->postmeta}` WHERE `meta_key` = 'ad-range' AND `post_id` = {$post} LIMIT 1;";
		$list = $wpdb->get_results($querystr, OBJECT);
		return $list[0]->meta_value;
	}

	// Widget Backend
	public function form( $instance )
	{
		global $wpdb;
		wp_enqueue_script('jquery');
		wp_enqueue_script('ad_placement_widget',plugin_dir_url(__FILE__).'js/widget.js',array('jquery'));

		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
		}
		else {
			$title = 'Ad set 1';
		}

		$querystr = "
		    SELECT DISTINCT $wpdb->posts.*, $wpdb->postmeta.meta_value as adrange
    		FROM $wpdb->posts
    		LEFT JOIN $wpdb->postmeta ON ($wpdb->posts.ID = $wpdb->postmeta.post_id)
    		WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id
    		AND $wpdb->posts.post_type = 'ads'
    		AND $wpdb->posts.post_status = 'publish'
    		AND $wpdb->postmeta.meta_key = 'ad-range'
		";

		$list = $wpdb->get_results($querystr, OBJECT);

		$add_section = $ad_array = '';
		if (isset($list[0]) && isset($instance['id']))
		{
			$ads_list = $this->get_all($instance['id']);
			if (isset($list[0]))
			{
				$add_section .= "Assigned ads:<p id='ad_list_{$instance['id']}'>";
				foreach ($ads_list as $placed_ad)
				{
					$ttl = get_the_title( $placed_ad->ad_id );
					$add_section .= "<span id = 'w_{$instance['id']}_ad_{$placed_ad->ad_id}'><i>$ttl</i> [{$placed_ad->often}] <a href='#' class='promosuite-ads-delete' data-widget='{$instance['id']}' data-ad='{$placed_ad->ad_id}'>delete</a><br></span>";
				}
				$add_section .= "</p><hr>";
			}


			$add_section .= "New:<br>";
			$add_section .= '<select style="width:210px;" id="value_ad_'.$instance['id'].'">';

			$ad_array .= '<script>var ad_array = [];';
			foreach ($list as $ad)
			{
				$ad_array.= "ad_array[{$ad->ID}] = '{$ad->post_title}';";
				$add_section .= "<option value='$ad->ID'>$ad->post_title</option>";
			}
			$ad_array .= '</script>';
			$add_section .= '</select>';
			$add_section .= '<label>How often:<input type="text" id="often_ad_'.$instance['id'].'" name="often" style="width:40px;" value="1"></label>
								<input type="button" class="button button_ad_" value="Add" data-id="'.$instance['id'].'">';
		}
		elseif (!isset($instance['id'])) $add_section .= "<b>Enter title and press save before adding any ADs to new campaign.</b>";
		else $add_section .= "Create ad to add it into placement.";
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>


		<?php
		echo $add_section;
		echo $ad_array;
	}

	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance )
	{
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['id'] = ( ! empty( $old_instance['id'] ) ) ? $old_instance['id']:uniqid();
		return $instance;
	}
}

// Register and load the widget
function ad_load_widget()
{
	wp_enqueue_script('jquery');
	register_widget( 'ad_widget' );
}
add_action( 'widgets_init', 'ad_load_widget' );
?>